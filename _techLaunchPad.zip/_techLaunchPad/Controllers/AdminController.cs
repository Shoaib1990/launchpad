using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using _techLaunchPad.Models;

namespace _techLaunchPad.Controllers{
    public class AdminController : Controller{

        
        private LaunchPadHome launchPadHome;

        public AdminController(LaunchPadHome launchPad) {
            //linkManager = launchPadlink;
            launchPadHome = launchPad;
        }

        public IActionResult Index(){
            Link link = new Link();
            Console.WriteLine("\n\n Index " + link.pinTop);
            
            return View(launchPadHome);
        }

        public IActionResult DeleteLinkPage(int linkId,string linkLabel, string linkUrl) {
            Console.WriteLine("\n\n" + linkId + " " + linkLabel + " " + linkUrl + "\n\n");
            ViewData["linkId"] = linkId;
            ViewData["linkLabel"] = linkLabel;
            ViewData["linkUrl"] = linkUrl;

            Link link = new Link();
            link.linkId = linkId;
            return View(link);
        }

        public IActionResult DeleteLink(Link link) {
            Console.WriteLine("\n\n" + link.linkId + "\n\n");
            launchPadHome.Remove(link);
            launchPadHome.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult EditCategoryPage(int Id, string category) {
            CategoryDB editCategory = new CategoryDB();
            Console.WriteLine("\n\n " + Id + " " + category + " \n\n");
            editCategory.Id = Id;
            editCategory.category = category;
            return View(editCategory);
        }

        public IActionResult EditCategory(CategoryDB categoryDB) {
            Console.WriteLine("\n\n editCategory:\n" + categoryDB.Id + " " + categoryDB.category + " \n\n");
            launchPadHome.Update(categoryDB);
            launchPadHome.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult EditLinkPage(int linkId,string linkLabel, string linkUrl, int pinTop, int categoryId) {
            Console.WriteLine("\n\n " + linkLabel + " " + pinTop + " \n\n");

            Link link = new Link();
            link.linkId = linkId;
            //link.pinTop = pinTop.ToString();
            if(link.pinTop=="0") {
                ViewData["checkBox"] = "checked";
            }
            CategoryDB myCategory = new CategoryDB();
            ViewBag.SelectList = launchPadHome.getCatList();
            //link = launchPadHome.selectCategory(Convert.ToInt32(linkId));
            
            return View(link);
        }

        [HttpPost]
        public IActionResult EditLinkSubmit(Link link) {
                        
            launchPadHome.Update(link);
            launchPadHome.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult AddPage(string id, string category) {
            CategoryDB myCategory = new CategoryDB();
            Console.WriteLine("\n\n categoryName " + id + " id " + category + "\n\n");
            Link link = new Link();
            myCategory.category = category;
            
            link.categoryId = Convert.ToInt32(id);
            ViewData["categoryName"] = category;
            //ViewBag.SelectList = launchPadHome.getCatList();
            //myCategory = launchPadHome.selectCategory(Convert.ToInt32(id));
            return View("AddPage",link);
        }

        [HttpPost]
        public IActionResult AddSubmit(string categoryId, string linkId) {
            Link link = new Link();
            //Console.WriteLine("\n\n LinkPage " + link.categoryId + "\n\n");
            //Console.WriteLine("\n\n LinkId " + link.linkId + "\n\n");
            if(link.pinTop=="false") {
                link.pinTop = "0";
            }

            //link = launchPadHome.selectCategory(link.linkId);
            //link = launchPadHome.selectCategory(link.categoryId);
            launchPadHome.Add(link);
            launchPadHome.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}