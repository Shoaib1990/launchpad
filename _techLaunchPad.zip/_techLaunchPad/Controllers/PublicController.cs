﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using _techLaunchPad.Models;

namespace _techLaunchPad.Controllers{
    public class PublicController : Controller{

        private LaunchPadHome laundPadHome;

        public PublicController(LaunchPadHome myLPHome) {
            laundPadHome = myLPHome;
        }

        public IActionResult Index(){
            return View(laundPadHome);
        }

    }
}
