namespace _techLaunchPad.Models{
    public class Connection{
        public const string CONNECTION_STRING = "Server=localhost; Database=grades;Uid=shoaib;Pwd=password;SslMode=none;";
    }
}

