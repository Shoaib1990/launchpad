using System;
using System.ComponentModel.DataAnnotations; // creattive programming

namespace _techLaunchPad.Models
{
    public class CategoryDB{

         // data notations
        //[Key]
        public int Id { get; set; }
        //[Required(ErrorMessage="Category Required!")]
        //[MaxLength(50)]
        //[Display(Name="Category Name")]
        public string category{ get; set; }
    }

    public class Link{

        //[Key]
        public int linkId {get;set;}
        //[Required(ErrorMessage="Link Label Required!")]
        //[MaxLength(50)]
        //[Display(Name="Link Label")]
        public string linkLabel {get;set;}
        //[Url]
        [Required(ErrorMessage="Link Required!")]
        //[MaxLength(100)]
        //[Display(Name="Link (Url)")]
        public string linkUrl {get;set;}
        public string pinTop {get;set;}
        // [ForeignKey("CategoryDB")]
        public int categoryId  {get;set;}

    }

}