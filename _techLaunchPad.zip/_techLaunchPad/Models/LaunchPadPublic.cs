using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System;

namespace _techLaunchPad.Models {

    public class LaunchPadHome : DbContext {

        public DbSet<CategoryDB> launchpadcategories {get;set;}

        public DbSet<Link> lplink {get;set;}
    
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            optionsBuilder.UseMySQL(Connection.CONNECTION_STRING);
        }

        public SelectList getCatList() {
            List<CategoryDB> listData = launchpadcategories.OrderBy(c => c.category).ToList();
            return new SelectList(listData,"Id","category");
        }

        public Link selectCategory(int categoryId) {            
            return lplink.Where(c => c.categoryId == categoryId ).FirstOrDefault();
        }
    }
}