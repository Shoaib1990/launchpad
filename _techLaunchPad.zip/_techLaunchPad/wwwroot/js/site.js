﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function startAutoLogout() {
    window.setTimeout(() => {
        // session has expired!
        document.location = "/";
        
    }, 1000*60*20);

    window.setTimeout(() => {
        // session has expired!
        document.getElementById("lblExpire").innerHTML = "Warning : Session is about to expire!";
    }, 1000*60*18);
}

let iconLink;
let urlHidden = $(".urlHidden").text();

// if(urlHidden.includes("http://")) {
//     urlHidden=urlHidden.substring(7);
//     iconLink = $(".iconLink").attr("src","https://www.google.com/s2/favicons?domain_url=" + urlHidden);
// }



console.log(urlHidden);

console.log(iconLink + " imgLink");